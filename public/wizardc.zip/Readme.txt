Thank you for downloading WizardC 7.3

WizardC7 is the 7th version I made and 3rd version released to the public. WizardC7 is a Harry Potter currency converter.

Installation: Right click on the WizardC7 program and click "Send to TI Device".

Compatible: This program is cross-compatible with the TI 84 Plus\SE\CSE

Version History:

GallionC: 1st version I made. Asked you to convert Dollars to Gallions, Gallions to Dollars, Sickles to Dollars, Dollars to Sickles, Gallions to Sickles, Sickles to Gallions, Knuts to Sickles, Gallions to Knuts, Knuts to Gallions, and Sickles to Knuts all seperatly.
Wizardcu: 2nd version I made. Found a way to change the program to Dollars to Gallions, Sickles, and Knuts and vise versa.
WizardC3: 3rd version I made. Fixed issues with results by putting it in the graph screen instead of home screen. Input Dollars, Gallions, Sickles, and Knuts instead of prompting A, B, C, and D. Added "about" in menu.
WizardC4: 4th version I made. Added taskbar at bottom (making the program only compatible for the ti 84 plus/SE). Replaced menu with custom menu.
WizardC5: 5th version I made. Moved 2 options from the menu and put them on the taskbar. Choose between user input or classic. Added a border around the 2 remaining options in the menu. 1st public release.
WizardC6: 6th version I made. Compatible only for the TI 84 Plus C Silver Edition (Added Background picture of Gringotts Bank. Changed "Dollars?" in User Input to "$". Made the "X" in the Main Menu red and made all "$" signs green. 2nd public release.
WizardC7: 7th version I made. This program is cross-compatible with the TI 84 Plus\SE\CSE. Removed background picture to speed up program and make the text neater. Lowercase letters. Added calculator model in "About" section. Added arrows in "user input" to make it easier for the user. 3rd public release.

WizardC 7.0.1 update: Saved around 1000 bytes of space.
WizardC 7.1 update(A.K.A WizardC 7 September update): 2 arrows in the Main Menu pointing at the selection. All objects are now in 3D.
WizardC 7.2 update(A.K.A WizardC 7 October update): Splashscreen with animation. More 3D objects. Cooler About button in Main Menu. A few more changes in the UI.
WizardC 7.3 update(A.K.A WizardC 7 November update): 3D object in Exit screen. Colorful text on TI 84 Plus CSE. Shows what option your in in Choose Format screen.

Plans for future versions: z80 Assembly program or App. Change arrows in "Main Menu" to Griphook the Goblin's hand. 3D text. Readme in PDF.